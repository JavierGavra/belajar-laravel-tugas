
<?php $__env->startSection('content'); ?>
Ini halaman keranjang
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Tugas\Sarjana\Semester 4\Pemrograman Web Lanjut\belajar-laravel\resources\views/v_keranjang.blade.php ENDPATH**/ ?>