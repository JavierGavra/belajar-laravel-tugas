@extends('layout')
@section('content')
Ini halaman produk
@endsection