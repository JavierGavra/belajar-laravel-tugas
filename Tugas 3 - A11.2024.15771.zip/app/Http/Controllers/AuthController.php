<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        if ($request->isMethod('post')) {
            $username = $request->input('username');
            $password = $request->input('password');

            // Data user hardcoded (password: 123 dalam md5)
            $dataUser = [
                'username' => 'rusdi',
                'password'  => '1df9f838e47c40db0a1d6f3b869781ad',
                'role'      => 'admin'
            ];

            if ($username == $dataUser['username']) {
                if (md5($password) == $dataUser['password']) {
                    $request->session()->put([
                        'username'   => $dataUser['username'],
                        'role'       => $dataUser['role'],
                        'isLoggedIn' => true,
                    ]);

                    return redirect('/');
                } else {
                    return redirect()->back()
                        ->with('failed', 'Username & Password Salah');
                }
            } else {
                return redirect()->back()
                    ->with('failed', 'Username Tidak Ditemukan');
            }
        }

        return view('v_login');
    }

    public function logout(Request $request)
    {
        $request->session()->flush();
        return redirect('login');
    }
}