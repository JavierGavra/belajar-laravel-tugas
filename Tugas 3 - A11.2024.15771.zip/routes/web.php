<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ProdukController;
use App\Http\Controllers\TransaksiController;
use Illuminate\Support\Facades\Route;

Route::middleware('auth.session')->group(function () {
    Route::get('/', [HomeController::class, 'index']);
    Route::get('/produk', [ProdukController::class, 'index']);
    Route::get('/keranjang', [TransaksiController::class, 'index']);
});

Route::get('/login', [AuthController::class, 'login']);
Route::post('/login', [AuthController::class, 'login']);
Route::get('/logout', [AuthController::class, 'logout']);
