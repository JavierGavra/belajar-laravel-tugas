

<?php $__env->startSection('content'); ?> 
<?php if(session('success')): ?>
    <div class="alert alert-info alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if(session('failed')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(session('failed')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal">
    Tambah Data
</button>

<table class="table datatable">
    <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Nama</th>
            <th scope="col">Harga</th>
            <th scope="col">Jumlah</th>
            <th scope="col">Foto</th>
            <th scope="col"></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($loop->iteration); ?></th>
                
                <td><?php echo e($produk->nama); ?></td>
                <td><?php echo e($produk->harga); ?></td>
                <td><?php echo e($produk->jumlah); ?></td>
                
                <td>
                    <?php if($produk->foto && file_exists(public_path('img/' . $produk->foto))): ?>
                        <img src="<?php echo e(asset('img/' . $produk->foto)); ?>" width="100" alt="Foto <?php echo e($produk->nama); ?>">
                    <?php endif; ?>
                </td>
                
                <td>
                    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#editModal-<?php echo e($produk->id); ?>">
                        Ubah
                    </button>

                    <a href="<?php echo e(url('produk/delete/' . $produk->id)); ?>" class="btn btn-danger" onclick="return confirm('Yakin hapus data ini ?')">
                        Hapus
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php echo $__env->make('produk.modal_add', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('produk.modal_edit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Tugas\Sarjana\Semester 4\Pemrograman Web Lanjut\belajar-laravel\resources\views/produk/index.blade.php ENDPATH**/ ?>