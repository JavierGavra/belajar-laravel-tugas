<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
<div class="modal fade" id="editModal-<?php echo e($produk->id); ?>" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Data</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <form action="<?php echo e(url('produk/edit/' . $produk->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="modal-body">
                    <div class="mb-3">
                        <label for="nama-<?php echo e($produk->id); ?>" class="form-label">Nama</label>
                        <input type="text" name="nama" id="nama-<?php echo e($produk->id); ?>" class="form-control" value="<?php echo e($produk->nama); ?>" placeholder="Nama Barang" required>
                    </div>

                    <div class="mb-3">
                        <label for="harga-<?php echo e($produk->id); ?>" class="form-label">Harga</label>
                        <input type="number" name="harga" id="harga-<?php echo e($produk->id); ?>" class="form-control" value="<?php echo e($produk->harga); ?>" placeholder="Harga Barang" required>
                    </div>

                    <div class="mb-3">
                        <label for="jumlah-<?php echo e($produk->id); ?>" class="form-label">Jumlah</label>
                        <input type="number" name="jumlah" id="jumlah-<?php echo e($produk->id); ?>" class="form-control" value="<?php echo e($produk->jumlah); ?>" placeholder="Jumlah Barang" required>
                    </div>

                    <div class="mb-3">
                        <?php if($produk->foto): ?>
                            <img src="<?php echo e(asset('img/' . $produk->foto)); ?>" width="100" alt="Foto <?php echo e($produk->nama); ?>">
                        <?php else: ?>
                            <span class="text-muted">Belum ada foto</span>
                        <?php endif; ?>
                    </div>

                    <div class="form-check mb-3">
                        <input type="checkbox" name="check" id="check-<?php echo e($produk->id); ?>" value="1" class="form-check-input">
                        <label class="form-check-label" for="check-<?php echo e($produk->id); ?>">
                            Ceklis jika ingin mengganti foto
                        </label>
                    </div>

                    <div class="mb-3">
                        <label for="foto-<?php echo e($produk->id); ?>" class="form-label">Foto</label>
                        <input type="file" name="foto" id="foto-<?php echo e($produk->id); ?>" class="form-control">
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        Close
                    </button>
                    <button type="submit" class="btn btn-primary">
                        Simpan
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\Tugas\Sarjana\Semester 4\Pemrograman Web Lanjut\belajar-laravel\resources\views/produk/modal_edit.blade.php ENDPATH**/ ?>