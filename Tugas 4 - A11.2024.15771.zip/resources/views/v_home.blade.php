@extends('layout')
@section('content')
@foreach ($products as $key => $item)         
    <div class="row">
        @foreach ($products as $key => $item)         
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <img src="{{ asset('img/' . $item['foto']) }}" alt="..." width="50%">
                        <h5 class="card-title">{{ $item['nama'] }}<br>{{ $item['harga'] }}</h5>
                    </div>
                </div>
            </div> 
        @endforeach 
    </div>        
@endforeach

@endsection